public class Sammlungskonto {

    private String id;

    public Sammlungskonto(String id) {
        this.id = id;
    }
}
