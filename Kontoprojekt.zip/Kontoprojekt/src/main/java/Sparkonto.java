public class Sparkonto extends Girokonto{

    public Sparkonto(String eigentuemer) {
        super(eigentuemer);
    }
}
