import java.math.BigDecimal;

public class Girokonto{

    private String eigentuemer;
    private BigDecimal kontostand;
    private BigDecimal dispo;
    private BigDecimal kreditLimit;

    public Girokonto(String eigentuemer) {
        this.eigentuemer = eigentuemer;
        this.kontostand = new BigDecimal(0);
    }

    public void einzahlen(BigDecimal betrag) {
        this.kontostand = kontostand.add(betrag);
    }

    /*
    Bei Konto über 2500 entfallen die Gebühren.
    zwischen 2500 und 0 Kontostand = 1 Euro Buchungsgebühr
    Bei Kreditrahmen = 2 Euro Buchungsgebühr
    Bei Kreditrahmen + Dispo = 4 Euro;
     */

    public void auszahlen(BigDecimal betrag) {
        if (kontostand.subtract(betrag).doubleValue() < dispo.doubleValue()) {
            if(kontostand.subtract(betrag).doubleValue() < -dispo.doubleValue()-kreditLimit.doubleValue()) {
                throw new IllegalArgumentException("Auszahlungs Betrag zum abbuchen ist zu hoch!");
            } else {

            }
        }
    }

    public String getEigentuemer() {
        return eigentuemer;
    }

    public void setDispo(BigDecimal betrag) {
        this.dispo = betrag;
    }

    public BigDecimal getDispo() {
        return dispo;
    }

    public void setKredit(BigDecimal betrag) {
        this.kreditLimit = betrag;
    }

    public BigDecimal getKreditLimit() {
        return this.kreditLimit;
    }
}
